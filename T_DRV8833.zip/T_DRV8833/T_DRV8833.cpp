/*
 * T_DRV8833 - Library for the DRV8833 dual motor driver carrier.
 * The DRV8833 can be found here: https://www.pololu.com/product/2130
 * The DRV8833 data sheet can be found here: https://www.pololu.com/file/download/drv8833.pdf?file_id=0J534
 *
 * Library: T_DRV8833
 * File: T_DRV8833.cpp
 *
 * Defines the class for the library.
 * v1.0
 *
 * Library based on code of Aleksandr J. Spackman.
 *
 * Library modified for GEC 2021 Board.
 *
 */

#include "Arduino.h"
#include "analogWrite.h"
#include "T_DRV8833.h"

T_DRV8833::T_DRV8833()
{
	// Does nothing.
	// Use vincularMotor1() and vincularMotor2().
}

void T_DRV8833::motor1Atras()
{
	if (this->motor1Vinculado) // If motor A is attached...
	{
		// ...then put it in reverse.
		digitalWrite(this->a1, LOW);
		digitalWrite(this->a2, HIGH);
	}
}

void T_DRV8833::motor1Atras(int velocidad)
{
	if (this->motor1Vinculado) // If motor A is attached...
	{
		// ...then put it in reverse.
		digitalWrite(this->a1, LOW);
		analogWrite(this->a2, velocidad);
	}
}

void T_DRV8833::motor1Adelante()
{
	if (this->motor1Vinculado) // If motor A is attached...
	{
		// ...then put it in forward.
		digitalWrite(this->a1, HIGH);
		digitalWrite(this->a2, LOW);
	}
}

void T_DRV8833::motor1Adelante(int velocidad)
{
	if (this->motor1Vinculado) // If motor A is attached...
	{
		// ...then put it in forward.
		analogWrite(this->a1, velocidad);
		digitalWrite(this->a2, LOW);
	}
}

void T_DRV8833::motor1Stop()
{
	if (this->motor1Vinculado) // If motor A is attached...
	{
		// ...then stop it.
		digitalWrite(this->a1, HIGH);
		digitalWrite(this->a2, HIGH);
	}
}

void T_DRV8833::motor2Atras()
{
	if (this->motor2Vinculado) // If motor B is attached...
	{
		// ...then put it in reverse.
		digitalWrite(this->b1, LOW);
		digitalWrite(this->b2, HIGH);
	}
}

void T_DRV8833::motor2Atras(int velocidad)
{
	if (this->motor2Vinculado) // If motor B is attached...
	{
		// ...then put it in reverse.
		digitalWrite(this->b1, LOW);
		analogWrite(this->b2, velocidad);
	}
}

void T_DRV8833::motor2Adelante()
{
	if (this->motor2Vinculado) // If motor B is attached...
	{
		// ...then put it in forward.
		digitalWrite(this->b1, HIGH);
		digitalWrite(this->b2, LOW);
	}
}

void T_DRV8833::motor2Adelante(int velocidad)
{
	if (this->motor2Vinculado) // If motor B is attached...
	{
		// ...then put it in forward.
		analogWrite(this->b1, velocidad);
		digitalWrite(this->b2, LOW);
	}
}

void T_DRV8833::motor2Stop()
{
	if (this->motor2Vinculado) // If motor B is attached...
	{
		// ...then stop it.
		digitalWrite(this->b1, HIGH);
		digitalWrite(this->b2, HIGH);
	}
}

void T_DRV8833::vincularMotor1(int a1, int a2)
{
	if (!this->motor1Vinculado) // If motor A is NOT attached...
	{
		// ...attach motor A to the input pins.
		pinMode(a1, OUTPUT);
		pinMode(a2, OUTPUT);
		this->a1 = a1;
		this->a2 = a2;

		// Show the motor is attached.
		this->motor1Vinculado = true;

		// Initialize as LOW.
		digitalWrite(this->a1, LOW);
		digitalWrite(this->a2, LOW);
	}
}

void T_DRV8833::vincularMotor2(int b1, int b2)
{
	if (!this->motor2Vinculado) // If motor B is NOT attached...
	{
		// ...attach motor A to the input pins.
		pinMode(b1, OUTPUT);
		pinMode(b2, OUTPUT);
		this->b1 = b1;
		this->b2 = b2;

		// Show the motor is attached.
		this->motor2Vinculado = true;

		// Initialize as LOW.
		digitalWrite(this->b1, LOW);
		digitalWrite(this->b2, LOW);
	}
}