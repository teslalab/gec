/*
 * DRV8833 - Library for the DRV8833 dual motor driver carrier.
 * The DRV8833 can be found here: https://www.pololu.com/product/2130
 * The DRV8833 data sheet can be found here: https://www.pololu.com/file/download/drv8833.pdf?file_id=0J534
 *
 * Library: T_DRV8833
 * File: T_DRV8833.h
 *
 * Describes the class for the library.
 * v1.0
 *
 * Based on Aleksandr J. Spackman library.
 * https://github.com/TheArduinist/DRV8833
 * 
 *
 * Library adapted for GEC KIT 2021 Board.
 */

#ifndef T_DRV8833_H
#define T_DRV8833_H

#include "Arduino.h"
#include "analogWrite.h"

class T_DRV8833
{
public:
	// Constructor for the class:
	T_DRV8833();

	// Motor control functions:
	void motor1Atras();
	void motor1Atras(int velocidad);
	void motor1Adelante();
	void motor1Adelante(int velocidad);
	void motor1Stop();

	void motor2Atras();
	void motor2Atras(int velocidad);
	void motor2Adelante();
	void motor2Adelante(int velocidad);
	void motor2Stop();

	// Functions to attach motors:
	void vincularMotor1(int a1 /* Input pin A1 */, int a2 /* Input pin A2 */);
	void vincularMotor2(int b1 /* Input pin B1 */, int b2 /* Input pin B2 */);

private:
	// Fields for the class:
	int a1, a2, b1, b2;
	boolean motor1Vinculado = false;
	boolean motor2Vinculado = false;
};

#endif // T_DRV8833_H